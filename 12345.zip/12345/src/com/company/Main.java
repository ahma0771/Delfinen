package com.company;

import java.util.*;
import java.io.*;

class Main{

   public static void main(String[]args){
      Administrator administrator = new Administrator();
      Scanner sc = new Scanner(System.in);   
      administrator.showMainMenu(sc);    
   }
   
}